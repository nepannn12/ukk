<?php
session_start();
include 'conn.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Mobil | Landing Page</title>
    <script src="https://cdn.tailwindcss.com"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background-image: url('https://images.unsplash.com/photo-1459603677915-a62079ffd002?q=80&w=1534&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'); /* Ganti dengan URL gambar hero yang sesuai */
            background-size: cover;
            background-position: center;
            height: 100vh;
            color: white;
        }

        .hero-content {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6); /* Overlay gelap */
        }

        .hero-content h1 {
            font-size: 4rem;
            margin-bottom: 20px;
        }

        .hero-content p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }

        .btn-custom {
            padding: 10px 30px;
            font-size: 1.2rem;
            border-radius: 50px;
        }

        .features-section {
            padding: 60px 0;
        }

        .feature-box {
            text-align: center;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            transition: all 0.3s ease-in-out;
        }

        .feature-box:hover {
            background-color: #f8f9fa;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #343a40;
            color: white;
            padding: 20px 0;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <!-- Navbar -->
<nav class="bg-gray-800 p-4">
    <div class="container mx-auto flex justify-between items-center">
        <a class="text-white text-2xl font-bold" href="#">RentalMobil</a>
        <div class="hidden md:flex space-x-4">
            <a class="text-white hover:bg-gray-700 px-3 py-2 rounded" href="#">Home</a>
            <!-- <a class="text-white hover:bg-gray-700 px-3 py-2 rounded" href="#">About</a>
            <a class="text-white hover:bg-gray-700 px-3 py-2 rounded" href="#">Services</a>
            <a class="text-white hover:bg-gray-700 px-3 py-2 rounded" href="#">Contact</a> -->
            <a class="bg-blue-600 text-white px-3 py-2 rounded" href="register.php">Registrasi</a>
            <a class="bg-blue-600 text-white px-3 py-2 rounded" href="login.php">Login</a>
        </div>
    </div>
</nav>


    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-content text-center">
            <h1>Rental Mobil Terbaik</h1>
            <p>Temukan mobil yang sesuai untuk perjalanan Anda dengan layanan rental kami yang cepat dan mudah.</p>
            <a href="#features" class="btn btn-custom btn-primary">Mulai Sekarang</a>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section" id="features">
        <div class="container">
            <h2 class="text-center mb-5">Mengapa Memilih Kami?</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="feature-box">
                        <i class="bi bi-car-front fs-1 mb-3"></i>
                        <h4>Mobil Terbaru</h4>
                        <p>Kami menyediakan berbagai pilihan mobil terbaru untuk kebutuhan perjalanan Anda.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-box">
                        <i class="bi bi-shield-check fs-1 mb-3"></i>
                        <h4>Keamanan Terjamin</h4>
                        <p>Setiap mobil kami selalu dalam kondisi terbaik dan terjamin keamanannya.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-box">
                        <i class="bi bi-clock fs-1 mb-3"></i>
                        <h4>Layanan 24 Jam</h4>
                        <p>Butuh mobil kapan saja? Kami siap melayani Anda 24/7 dengan respon cepat.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="p-4 sm:ml-64 mt-14">
        

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 p-4 ">
            <?php
            $query = "SELECT * FROM tb_mobil";
            $result = mysqli_query($conn, $query);

            while ($row = mysqli_fetch_assoc($result)) {
                $nopol = $row['nopol'];
                $checkBookingQuery = "SELECT COUNT(*) as count FROM tb_mobil WHERE nopol = '$nopol' AND status = 'tidak'";
                $checkBookingResult = mysqli_query($conn, $checkBookingQuery);
                $bookingData = mysqli_fetch_assoc($checkBookingResult);
                $isAvailable = $bookingData['count'] == 0;
            ?>

                <div class="bg-gray-800 rounded-lg shadow-lg overflow-hidden p-4 text-white">
                    <div class="flex justify-center items-center my-2 w-full h-40 overflow-hidden group">
                        <img src="image/<?= $row['foto'] ?>" alt="Car Image" class="w-full h-40 group-hover:scale-1.2 object-contain rounded-md">
                    </div>
                    <h3 class="text-lg font-bold"><?= $row['brand'] ?> - <?= $row['type'] ?></h3>
                    <p class="text-sm text-gray-400 mb-2"><?= $row['nopol'] ?> | <?= $row['tahun'] ?></p>
                    <p class="text-xl font-semibold mb-2">Rp <?= number_format($row['harga'], 0, ',', '.') ?> / hari</p>

                    <div class="flex justify-between items-center mt-4">
                        <span class="text-sm <?= $isAvailable ? 'text-emerald-500' : 'text-red-500' ?>">
                            <?= $isAvailable ? 'Available' : 'Booked' ?>
                        </span>

                        <?php if ($isAvailable): ?>
                            <button onclick="bookingMobil('<?= $row['nopol'] ?>', <?= $row['harga'] ?>)"
                                class="bg-emerald-700 hover:bg-emerald-800 text-white text-sm px-4 py-2 rounded-md">
                                Booking
                            </button>
                        <?php else: ?>
                            <button onclick="alert('Mobil ini sudah dibooking.')"
                                class="bg-red-700 hover:bg-red-800 text-white text-sm px-4 py-2 rounded-md">
                                Booked
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php } ?>
        </div>

    </div>

    <div id="bookingModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-gray-800 rounded-lg animate__animated animate__fadeInUp animate__faster p-6 w-full max-w-md">
            <button onclick="closeBooking()" class="text-white float-right">✕</button>

            <!-- Notifikasi Error -->
            <div id="errorMessage" class="text-red-500 text-sm font-semibold hidden mb-4"></div>

            <form class="space-y-4 mt-4" action="user/booking_mobil.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                <!-- Input untuk No Polisi -->
                <div>
                    <label for="nopol" class="block text-sm font-medium text-white">No. Polisi</label>
                    <input type="hidden" id="nopol" name="nopol" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" >
                </div>

                <!-- Input Tanggal Ambil -->
                <div>
                    <label for="tgl_ambil" class="block text-sm font-medium text-white">Tanggal Ambil</label>
                    <input type="date" id="tgl_ambil" name="tgl_ambil" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" required>
                </div>

                <!-- Input Tanggal Kembali -->
                <div>
                    <label for="tgl_kembali" class="block text-sm font-medium text-white">Tanggal Kembali</label>
                    <input type="date" id="tgl_kembali" name="tgl_kembali" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" required>
                </div>

                <!-- Input DP -->
                <div>
                    <label for="dp" class="block text-sm font-medium text-white">Bayar DP</label>
                    <input type="number" id="dp" name="dp" placeholder="Rp" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" required>
                </div>

                <!-- Radio untuk Supir -->
                <div>
                    <label class="block text-sm font-medium text-white">Pakai Supir</label>
                    <div class="flex items-center space-x-4">
                        <label class="flex items-center">
                            <input type="radio" name="supir" value="1" class="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500" required>
                            <span class="ml-2 text-sm text-white">Ya</span>
                        </label>
                        <label class="flex items-center">
                            <input type="radio" name="supir" value="0" class="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500" required checked>
                            <span class="ml-2 text-sm text-white">Tidak</span>
                        </label>
                    </div>
                </div>

                <!-- Display Total Harga -->
                <div>
                    <label class="block text-sm font-medium text-white">Total Harga</label>
                    <p id="totalHarga" class="text-lg font-semibold text-white">Rp 0</p>
                </div>

                <!-- Tombol Simpan -->
                <button type="submit" id="submitButton" name="btnSimpan" class="w-full bg-blue-700 hover:bg-blue-800 text-white rounded-lg py-2.5">
                    Simpan
                </button>
            </form>
        </div>
    </div>

    <script>
        let harga = 0;

        function bookingMobil(nopol, hargaL) {
            // Mengisi input no polisi dalam modal dengan nilai dari parameter nopol
            document.getElementById("nopol").value = nopol;
            harga = hargaL;

            // Mengatur tanggal default untuk tanggal ambil dan tanggal kembali
            const tglAmbilInput = document.getElementById("tgl_ambil");
            const tglKembaliInput = document.getElementById("tgl_kembali");

            const today = new Date();
            today.setDate(today.getDate() + 1); // Tanggal Ambil adalah besok
            const threeDaysLater = new Date(today);
            threeDaysLater.setDate(threeDaysLater.getDate() + 2); // Tanggal Kembali 3 hari setelah ambil

            tglAmbilInput.valueAsDate = today;
            tglKembaliInput.valueAsDate = threeDaysLater;

            // Menampilkan modal
            document.getElementById("bookingModal").classList.remove("hidden");

            // Update total harga awal
            updateTotalHarga();
        }

        function closeBooking() {
            document.getElementById("nopol").value = "";
            harga = 0;
            // Menyembunyikan modal
            document.getElementById("bookingModal").classList.add("hidden");
        }

        function updateTotalHarga() {
            const tanggalAmbil = new Date(document.getElementById("tgl_ambil").value);
            const tanggalKembali = new Date(document.getElementById("tgl_kembali").value);
            const daysDifference = Math.ceil((tanggalKembali - tanggalAmbil) / (1000 * 60 * 60 * 24));
            const pakaiSupir = document.querySelector('input[name="supir"]:checked').value === "1";

            let totalHarga = harga * daysDifference;

            // Tambahkan biaya supir jika dipilih
            if (pakaiSupir) {
                totalHarga += 100000 * daysDifference;
            }

            document.getElementById("totalHarga").textContent = `Rp ${totalHarga.toLocaleString()}`;
        }

        function validateForm() {
            const errorMessage = document.getElementById("errorMessage");
            const tanggalAmbil = new Date(document.getElementById("tgl_ambil").value);
            const tanggalKembali = new Date(document.getElementById("tgl_kembali").value);
            const dp = parseFloat(document.getElementById("dp").value);
            const hargaSewa = harga;

            // Clear previous error messages
            errorMessage.classList.add("hidden");
            errorMessage.textContent = "";

            // Validation for Tanggal Ambil (should be at least tomorrow)
            const minAmbilDate = new Date();
            minAmbilDate.setDate(minAmbilDate.getDate() + 1);
            if (tanggalAmbil < minAmbilDate) {
                errorMessage.textContent = "Tanggal Ambil minimal besok.";
                errorMessage.classList.remove("hidden");
                return false;
            }

            // Validation for Tanggal Kembali (should be at least 1 day after Tanggal Ambil)
            const minReturnDate = new Date(tanggalAmbil);
            minReturnDate.setDate(minReturnDate.getDate() + 1);
            if (tanggalKembali < minReturnDate) {
                errorMessage.textContent = "Tanggal Kembali minimal sehari setelah Tanggal Ambil.";
                errorMessage.classList.remove("hidden");
                return false;
            }

            // Validation for DP (should be between 20% and 100% of hargaSewa)
            const minDp = hargaSewa * 0.2;
            const maxDp = hargaSewa;
            if (dp < minDp || dp > maxDp) {
                errorMessage.textContent = `DP harus antara Rp ${minDp.toLocaleString()} dan Rp ${maxDp.toLocaleString()}.`;
                errorMessage.classList.remove("hidden");
                return false;
            }

            // If all validations pass, allow the form to submit
            return true;
        }

        // Event listeners untuk update total harga dan validasi saat input berubah
        document.getElementById("tgl_ambil").addEventListener("change", () => {
            validateForm();
            updateTotalHarga();
        });

        document.getElementById("tgl_kembali").addEventListener("change", () => {
            validateForm();
            updateTotalHarga();
        });

        document.querySelectorAll('input[name="supir"]').forEach(radio => {
            radio.addEventListener("change", updateTotalHarga);
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
