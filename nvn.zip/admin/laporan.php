<?php
include('../conn.php'); // Sesuaikan path jika diperlukan
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
    <title>Laporan Peminjaman Mobil</title>
</head>
<body class="bg-gray-200">
    <?php include 'navbar.php'; ?>

    <div class="p-4 sm:ml-64 mt-14">
        <h1 class="text-center text-2xl font-bold mb-4">Laporan Peminjaman Mobil</h1>
        <div class="mb-4 d-flex justify-content-start">
            <a href="cetak.php" target="_blank" class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5">
                <i class="fas fa-print"></i> Cetak Data
            </a>
        </div>

        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th class="px-6 py-3 text-center">No</th>
                        <th class="px-6 py-3 text-center">NIK</th>
                        <th class="px-6 py-3 text-center">Nama</th>
                        <th class="px-6 py-3 text-center">Mobil</th>
                        <th class="px-6 py-3 text-center">Tanggal Ambil</th>
                        <th class="px-6 py-3 text-center">Tanggal Kembali</th>
                        <th class="px-6 py-3 text-center">Status Transaksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    $query = mysqli_query($conn, "SELECT tb_transaksi.*, tb_member.nama, tb_mobil.brand, tb_mobil.type 
                                                 FROM tb_transaksi
                                                 LEFT JOIN tb_member ON tb_member.nik = tb_transaksi.nik 
                                                 LEFT JOIN tb_mobil ON tb_mobil.nopol = tb_transaksi.nopol");
                    while ($data = mysqli_fetch_array($query)) {
                    ?>
                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <td class='px-6 py-4 text-center'><?php echo $i++; ?></td>
                            <td class='px-6 py-4 text-center'><?php echo $data['nik']; ?></td>
                            <td class='px-6 py-4 text-center'><?php echo $data['nama']; ?></td>
                            <td class='px-6 py-4 text-center'><?php echo $data['brand'] . ' ' . $data['type']; ?></td>
                            <td class='px-6 py-4 text-center'><?php echo $data['tgl_ambil']; ?></td>
                            <td class='px-6 py-4 text-center'><?php echo $data['tgl_kembali']; ?></td>
                            <td class='px-6 py-4 text-center'><?php echo $data['status']; ?></td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
