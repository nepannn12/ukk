<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Peminjaman Mobil</title>
    <style>
        /* CSS untuk tampilan cetak */
        @media print {
            @page {
                margin: 0; /* Hilangkan margin yang biasanya memunculkan URL di header/footer */
            }
            body {
                margin: 1cm; /* Tambahkan margin internal agar dokumen rapi */
            }

            /* Hilangkan elemen yang tidak diperlukan */
            .no-print {
                display: none;
            }
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 5px;
            text-align: center;
        }
    </style>
</head>
<body>

    <h2 align="center">Laporan Peminjaman Mobil</h2>
    <table>
        <tr>
            <th>No</th>
            <th>User</th>
            <th>Mobil</th>
            <th>Tanggal Ambil</th>
            <th>Tanggal Kembali</th>
            <th>Status Peminjaman</th>
        </tr>
        <?php
        include "../conn.php";
        $i = 1;
        $query = mysqli_query($conn, "SELECT tb_transaksi.*, tb_member.nama, tb_mobil.brand, tb_mobil.type 
                                         FROM tb_transaksi
                                         LEFT JOIN tb_member ON tb_member.nik = tb_transaksi.nik 
                                         LEFT JOIN tb_mobil ON tb_mobil.nopol = tb_transaksi.nopol");
        while($data = mysqli_fetch_array($query)) {
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['brand'] . ' ' . $data['type']; ?></td>
            <td><?php echo $data['tgl_ambil']; ?></td>
            <td><?php echo $data['tgl_kembali']; ?></td>
            <td><?php echo $data['status']; ?></td>
        </tr>
        <?php
        }
        ?>
    </table>

    <script>
        window.print();
        setTimeout(function() {
            window.close();
        }, 100);
    </script>

</body>
</html>