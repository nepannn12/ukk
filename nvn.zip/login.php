<?php
session_start();
include 'conn.php'; // pastikan koneksi ke database sudah diatur

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Mengambil data input dengan metode POST dan menghindari injeksi SQL
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = $_POST['password']; // password tidak perlu di-escape karena akan di-hash

  // Validasi jika username dan password tidak kosong
  if (!empty($username) && !empty($password)) {
    // Cek di tabel tb_user (admin/petugas)
    $query = "SELECT * FROM tb_user WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
      $user = mysqli_fetch_assoc($result);

      // Verifikasi password hash
      if (password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user;
        $_SESSION['role'] = $member['role'];


        // Redirect berdasarkan peran pengguna
        switch ($user['role']) {
          case 'admin':
            header('Location: admin/index.php');
            break;
          case 'petugas':
            header('Location: petugas/index.php');
            break;
          default:
            echo "<script>alert('Invalid role.');</script>";
            break;
        }
        exit();
      } else {
        echo "<script>alert('Invalid Username or Password.');</script>";
      }
    } else {
      // Jika tidak ditemukan di tb_user, coba cek di tb_member
      $query_member = "SELECT * FROM tb_member WHERE username = '$username'";
      $result_member = mysqli_query($conn, $query_member);

      if (mysqli_num_rows($result_member) == 1) {
        $member = mysqli_fetch_assoc($result_member);

        // Verifikasi password hash
        if (password_verify($password, $member['password'])) {
          $_SESSION['user'] = $member;
          header('Location: user/index.php'); // Ganti dengan lokasi yang sesuai untuk member
          exit();
        } else {
          echo "<script>alert('Invalid Username or Password.');</script>";
        }
      } else {
        echo "<script>alert('Invalid Username or Password.');</script>";
      }
    }
  } else {
    echo "<script>alert('Please enter Username and Password.');</script>";
  }
}
?>

<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
</head>
<!-- background -->
<body class="bg-gray-200">
<!-- background -->

  <div class="flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md p-8 space-y-8 bg-gray-800 rounded-lg shadow-md">
      <h2 class="text-2xl font-bold text-center text-gray-200">Login</h2>
      <form action="" method="POST">
        <div class="mb-4">
          <label for="username" class="block text-sm font-medium text-gray-200">Username</label>
          <input type="text" name="username" id="username" required
            class="w-full px-3 py-2 mt-1 border bg-gray-700 rounded-md focus:outline-none focus:ring text-gray-200 focus:ring-indigo-200">
        </div>
        <div class="mb-6">
          <label for="password" class="block text-sm font-medium text-gray-200">Password</label>
          <input type="password" name="password" id="password" required
            class="w-full px-3 py-2 mt-1 border bg-gray-700 rounded-md focus:outline-none focus:ring text-gray-200 focus:ring-indigo-200">
        </div>
        <div class="flex items-center justify-between">
          <button type="submit"
            class="w-full px-4 py-2 font-bold text-white bg-indigo-600 rounded hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">Login</button>
        </div>
      </form>
      <p class="mt-4 text-sm text-center text-gray-200">
        Belum Punya Akun? <a href="register.php" class="text-indigo-500 hover:underline">Register</a>
      </p>
    </div>
  </div>
</body>
</html>
