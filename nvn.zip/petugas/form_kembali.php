<?php
include 'conn.php'; // pastikan koneksi ke database sudah diatur

$id_transaksi = $_GET['id_transaksi'];

if (isset($_POST['btnSimpan'])) {
    $tgl_kembali = $_POST['tgl_kembali'];
    $kondisi_mobil = $_POST['kondisi_mobil'];
    $denda = isset($_POST['denda']) && is_numeric($_POST['denda']) ? (int)$_POST['denda'] : 0;

    // Ambil data transaksi
    $query = "SELECT * FROM tb_transaksi WHERE id_transaksi = '$id_transaksi'";
    $result = mysqli_query($conn, $query);
    $transaksi = mysqli_fetch_assoc($result);

    $tgl_kembali_transaksi = $transaksi['tgl_kembali'];
    $total = $transaksi['total'];
    $dp = $transaksi['dp'];
    $nopol = $transaksi['nopol']; // Assuming there's a nopol field in tb_transaksi

    // Hitung denda keterlambatan
    $denda_keterlambatan = 0;
    if (strtotime($tgl_kembali) > strtotime($tgl_kembali_transaksi)) {
        $diff = strtotime($tgl_kembali) - strtotime($tgl_kembali_transaksi);
        $days_late = ceil($diff / (60 * 60 * 24));
        $denda_keterlambatan = $days_late * 100000;
    }

    // Update total dan kekurangan
    $total += $denda_keterlambatan + $denda;
    $kekurangan = $total - $dp;

    // Insert ke tb_kembali
    $query = "INSERT INTO tb_kembali (id_transaksi, tgl_kembali, kondisi_mobil, denda) VALUES ('$id_transaksi', '$tgl_kembali', '$kondisi_mobil', '$denda')";
    mysqli_query($conn, $query);
    $id_kembali = mysqli_insert_id($conn);

    // Update tb_transaksi
    $query = "UPDATE tb_transaksi SET total = '$total', kekurangan = '$kekurangan', status = 'kembali' WHERE id_transaksi = '$id_transaksi'";
    mysqli_query($conn, $query);

    // Update tb_mobil
    $query = "UPDATE tb_mobil SET status = 'tersedia' WHERE nopol = '$nopol'";
    mysqli_query($conn, $query);

    // Insert ke tb_bayar
    $query = "INSERT INTO tb_bayar (id_kembali, total_bayar, status) VALUES ('$id_kembali', '$kekurangan', 'belum lunas')";
    mysqli_query($conn, $query);

    echo "<script>alert('Data berhasil disimpan.'); window.location.href='tb_kembali.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
    <title>ADMIN DASHBOARD</title>
</head>

<body class="bg-gray-200 flex items-center justify-center min-h-screen">
    <?php include 'navbar.php'; ?>

    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-center text-2xl font-bold mb-6">Kembalikan Mobil</h2>
        <form action="" method="POST">
            <div class="mb-4">
                <label for="username" class="block text-sm font-medium text-gray-700">Tanggal Kembali</label>
                <input type="date" name="tgl_kembali" id="username" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm">
            </div>
            <div class="mb-4">
                <label for="kondisi_mobil" class="block text-sm font-medium text-gray-700">Kondisi Mobil</label>
                <textarea name="kondisi_mobil" id="kondisi_mobil" required rows="4" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"></textarea>
            </div>
            <div class="mb-4">
                <label for="username" class="block text-sm font-medium text-gray-700">Denda</label>
                <input type="text" name="denda" id="username" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm">
            </div>
            <button type="submit" name="btnSimpan" class="w-full bg-emerald-600 text-white py-2 rounded-lg hover:bg-emerald-700 focus:outline-none focus:ring-4 focus:ring-emerald-300">Simpan</button>
        </form>
    </div>
</body>

</html>