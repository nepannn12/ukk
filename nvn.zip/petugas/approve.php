<?php
// approve_transaksi.php

session_start();
include 'conn.php';

if (isset($_GET['id_transaksi'])) {
    $id_transaksi = $_GET['id_transaksi'];

    $stmt = $conn->prepare("UPDATE tb_transaksi SET status = 'approve' WHERE id_transaksi = ?");
    $stmt->bind_param("i", $id_transaksi);
    $stmt->execute();

    // Redirect atau tampilkan pesan sukses
    header("Location: tb_ambil.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_transaksi'])) {
    $id_transaksi = $_POST['id_transaksi'];

    // Ambil data transaksi yang akan dipindahkan
    $stmt = $conn->prepare("SELECT * FROM tb_transaksi WHERE id_transaksi = ?");
    $stmt->bind_param("i", $id_transaksi);
    $stmt->execute();
    $result = $stmt->get_result();
    $transaksi = $result->fetch_assoc();

    // Pindahkan data ke tabel tb_ambil
    $stmt_insert = $conn->prepare("INSERT INTO tb_ambil (id_transaksi, nik, nopol, tgl_booking, tgl_ambil, tgl_kembali, supir, total, dp, kekurangan, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt_insert->bind_param(
        "issssssiiss",
        $transaksi['id_transaksi'],
        $transaksi['nik'],
        $transaksi['nopol'],
        $transaksi['tgl_booking'],
        $transaksi['tgl_ambil'],
        $transaksi['tgl_kembali'],
        $transaksi['supir'],
        $transaksi['total'],
        $transaksi['dp'],
        $transaksi['kekurangan'],
        $transaksi['status']
    );
    $stmt_insert->execute();

    // Ubah status transaksi menjadi 'ambil' di tb_transaksi
    $stmt_update = $conn->prepare("UPDATE tb_transaksi SET status = 'ambil' WHERE id_transaksi = ?");
    $stmt_update->bind_param("i", $id_transaksi);
    $stmt_update->execute();

    // Redirect atau tampilkan pesan sukses
    header("Location: daftar_sewa.php");
    exit();
}
?>


<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
    <title>PETUGAS DASHBOARD</title>
</head>

<body class="bg-gray-200">
    <?php include 'navbar.php'; ?>

    <div class="p-4 sm:ml-64 mt-14">
        <h1 class="text-center  text-2xl font-bold mb-4">Data Transaksi Member (Approve)</h1>

        <div class="grid grid-flow-col justify-start gap-x-2 mb-3">
            <a href="transaksi.php"
                class="text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-4 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 focus:outline-none dark:focus:ring-emerald-800">
                booking</a>
            <a href="approve.php"
                class="text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-4 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 focus:outline-none dark:focus:ring-emerald-800">
                approve</a>
            <a href="tb_ambil.php"
                class="text-white bg-yellow-700 hover:bg-yellow-800 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-yellow-600 dark:hover:bg-yellow-700 focus:outline-none dark:focus:ring-yellow-800">
                Diambil</a>
            <a href="tb_kembali.php"
                class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">
                Kembali</a>
        </div>

        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
            <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-center">
                            No
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            NAMA/NIK
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            No. Polisi
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            Tanggal Booking
                        </th>
                        <th scope="col" class="px-12 py-3 text-center">
                            Tanggal Pinjam
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            Supir
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            Total Harga
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            Pembayaran DP
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            Kekurangan
                        </th>
                        <th scope="col" class="px-6 py-3 text-center">
                            Status
                        </th>
                      
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT tb_transaksi.*, tb_member.nama FROM tb_transaksi
                    join tb_member on tb_member.nik = tb_transaksi.nik WHERE status = 'approve'";
                    $result = mysqli_query($conn, $query);
                    $no = 1;

                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                        <tr
                            class='bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600'>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                <?= $no++ ?>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                <p class="font-medium">
                                <?= $row['nama'] ?>

                                </p>
                                <small>
                                <?= $row['nik'] ?>

                                </small>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                <?= $row['nopol'] ?>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                <?= $row['tgl_booking'] ?>
                            </td>
                            
                            <td class='px-12 py-4 whitespace-nowrap text-center'>
                            <?= $row['tgl_ambil'] ?>
                            -
                            <?= $row['tgl_kembali'] ?>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                <?= $row['supir'] == 1 ? 'Ya' : 'Tidak' ?>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                Rp <?= number_format($row['total'], 0, ',', '.') ?>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                Rp <?= number_format($row['dp'], 0, ',', '.') ?>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                Rp <?= number_format($row['kekurangan'], 0, ',', '.') ?>
                            </td>
                            <td class='px-6 py-4 whitespace-nowrap text-center'>
                                <?= $row['status'] ?>
                            </td>
                            
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>