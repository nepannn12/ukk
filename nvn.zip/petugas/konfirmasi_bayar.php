<?php 
include 'conn.php';

$id_bayar = $_GET['id_bayar'];

$tgl_bayar = date('Y-m-d');
$status = 'lunas';

// Update tb_bayar
$sql = "UPDATE tb_bayar SET tgl_bayar = '$tgl_bayar', status = '$status' WHERE id_bayar = '$id_bayar'";
if (mysqli_query($conn, $sql)) {
    // Get id_kembali from tb_bayar
    $result = mysqli_query($conn, "SELECT id_kembali FROM tb_bayar WHERE id_bayar = '$id_bayar'");
    $row = mysqli_fetch_assoc($result);
    $id_kembali = $row['id_kembali'];

    // Get id_transaksi from tb_kembali
    $result = mysqli_query($conn, "SELECT id_transaksi FROM tb_kembali WHERE id_kembali = '$id_kembali'");
    $row = mysqli_fetch_assoc($result);
    $id_transaksi = $row['id_transaksi'];

    // Update kekurangan in tb_transaksi
    $sql = "UPDATE tb_transaksi SET kekurangan = 0 WHERE id_transaksi = '$id_transaksi'";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Pembayaran berhasil dikonfirmasi dan kekurangan telah diupdate.'); window.location.href='tb_bayar.php';</script>";
    } else {
        echo "Error updating kekurangan: " . mysqli_error($conn);
    }
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>