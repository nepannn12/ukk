<?php
session_start();
include 'conn.php';
?>

<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <title>USER</title>
</head>

<body class="bg-gray-200">
    <?php
    if(isset($_GET['message'])) :
    ?>

<div class="notivication  z-50 w-screen fixed top-0 left-0 flex px-4 items-center justify-center h-0">
        <div class="bg-white border-2 animate__animated animate__fadeOutUp animate__faster animate__delay-3s text-center mt-14 w-full max-w-96 shadow-md rounded-md px-3 items-center h-10 flex gap-2">
            <div class="flex-0 items-center justify-center">
                <svg class="w-6 h-6" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                    <path fill-rule="evenodd" d="M3.559 4.544c.355-.35.834-.544 1.33-.544H19.11c.496 0 .975.194 1.33.544.356.35.559.829.559 1.331v9.25c0 .502-.203.981-.559 1.331-.355.35-.834.544-1.33.544H15.5l-2.7 3.6a1 1 0 0 1-1.6 0L8.5 17H4.889c-.496 0-.975-.194-1.33-.544A1.868 1.868 0 0 1 3 15.125v-9.25c0-.502.203-.981.559-1.331ZM7.556 7.5a1 1 0 1 0 0 2h8a1 1 0 0 0 0-2h-8Zm0 3.5a1 1 0 1 0 0 2H12a1 1 0 1 0 0-2H7.556Z" clip-rule="evenodd" />
                </svg>
            </div>
            <div class="flex-1 line-clamp-1 w-full text-start border-s-4 ps-2"><?= $_GET['message'] ?></div>

        </div>
    </div>


    <?php
        endif;
    ?>
    <?php include 'navbar.php'; ?>
    <div class="p-4 sm:ml-64 mt-14">
        <h1 class="text-center  text-2xl font-bold mb-4">Data Mobil</h1>

        <div class="grid grid-flow-col justify-start gap-x-2 mb-3">
            <a href="tb_booking.php"
                class="text-white bg-emerald-700 hover:bg-emerald-800 focus:ring-4 focus:ring-emerald-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-emerald-600 dark:hover:bg-emerald-700 focus:outline-none dark:focus:ring-emerald-800">
                Transaksi Saya</a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 p-4 ">
            <?php
            $query = "SELECT * FROM tb_mobil";
            $result = mysqli_query($conn, $query);

            while ($row = mysqli_fetch_assoc($result)) {
                $nopol = $row['nopol'];
                $checkBookingQuery = "SELECT COUNT(*) as count FROM tb_mobil WHERE nopol = '$nopol' AND status = 'tidak'";
                $checkBookingResult = mysqli_query($conn, $checkBookingQuery);
                $bookingData = mysqli_fetch_assoc($checkBookingResult);
                $isAvailable = $bookingData['count'] == 0;
            ?>

                <div class="bg-gray-800 rounded-lg shadow-lg overflow-hidden p-4 text-white">
                    <div class="flex justify-center items-center my-2 w-full h-40 overflow-hidden group">
                        <img src="../image/<?= $row['foto'] ?>" alt="Car Image" class="w-full h-40 group-hover:scale-1.2 object-contain rounded-md">
                    </div>
                    <h3 class="text-lg font-bold"><?= $row['brand'] ?> - <?= $row['type'] ?></h3>
                    <p class="text-sm text-gray-400 mb-2"><?= $row['nopol'] ?> | <?= $row['tahun'] ?></p>
                    <p class="text-xl font-semibold mb-2">Rp <?= number_format($row['harga'], 0, ',', '.') ?> / hari</p>

                    <div class="flex justify-between items-center mt-4">
                        <span class="text-sm <?= $isAvailable ? 'text-emerald-500' : 'text-red-500' ?>">
                            <?= $isAvailable ? 'Available' : 'Booked' ?>
                        </span>

                        <?php if ($isAvailable): ?>
                            <button onclick="bookingMobil('<?= $row['nopol'] ?>', <?= $row['harga'] ?>)"
                                class="bg-emerald-700 hover:bg-emerald-800 text-white text-sm px-4 py-2 rounded-md">
                                Booking
                            </button>
                        <?php else: ?>
                            <button onclick="alert('Mobil ini sudah dibooking.')"
                                class="bg-red-700 hover:bg-red-800 text-white text-sm px-4 py-2 rounded-md">
                                Booked
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php } ?>
        </div>

    </div>

    <div id="bookingModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
        <div class="bg-gray-800 rounded-lg animate__animated animate__fadeInUp animate__faster p-6 w-full max-w-md">
            <button onclick="closeBooking()" class="text-white float-right">✕</button>

            <!-- Notifikasi Error -->
            <div id="errorMessage" class="text-red-500 text-sm font-semibold hidden mb-4"></div>

            <form class="space-y-4 mt-4" action="booking_mobil.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                <!-- Input untuk No Polisi -->
                <div>
                    <label for="nopol" class="block text-sm font-medium text-white">No. Polisi</label>
                    <input type="hidden" id="nopol" name="nopol" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" >
                </div>

                <!-- Input Tanggal Ambil -->
                <div>
                    <label for="tgl_ambil" class="block text-sm font-medium text-white">Tanggal Ambil</label>
                    <input type="date" id="tgl_ambil" name="tgl_ambil" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" required>
                </div>

                <!-- Input Tanggal Kembali -->
                <div>
                    <label for="tgl_kembali" class="block text-sm font-medium text-white">Tanggal Kembali</label>
                    <input type="date" id="tgl_kembali" name="tgl_kembali" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" required>
                </div>

                <!-- Input DP -->
                <div>
                    <label for="dp" class="block text-sm font-medium text-white">Bayar DP</label>
                    <input type="number" id="dp" name="dp" placeholder="Rp" class="w-full bg-gray-600 border border-gray-500 text-white rounded-lg p-2.5" required>
                </div>

                <!-- Radio untuk Supir -->
                <div>
                    <label class="block text-sm font-medium text-white">Pakai Supir</label>
                    <div class="flex items-center space-x-4">
                        <label class="flex items-center">
                            <input type="radio" name="supir" value="1" class="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500" required>
                            <span class="ml-2 text-sm text-white">Ya</span>
                        </label>
                        <label class="flex items-center">
                            <input type="radio" name="supir" value="0" class="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500" required checked>
                            <span class="ml-2 text-sm text-white">Tidak</span>
                        </label>
                    </div>
                </div>

                <!-- Display Total Harga -->
                <div>
                    <label class="block text-sm font-medium text-white">Total Harga</label>
                    <p id="totalHarga" class="text-lg font-semibold text-white">Rp 0</p>
                </div>

                <!-- Tombol Simpan -->
                <button type="submit" id="submitButton" name="btnSimpan" class="w-full bg-blue-700 hover:bg-blue-800 text-white rounded-lg py-2.5">
                    Simpan
                </button>
            </form>
        </div>
    </div>

    <script>
        let harga = 0;

        function bookingMobil(nopol, hargaL) {
            // Mengisi input no polisi dalam modal dengan nilai dari parameter nopol
            document.getElementById("nopol").value = nopol;
            harga = hargaL;

            // Mengatur tanggal default untuk tanggal ambil dan tanggal kembali
            const tglAmbilInput = document.getElementById("tgl_ambil");
            const tglKembaliInput = document.getElementById("tgl_kembali");

            const today = new Date();
            today.setDate(today.getDate() + 1); // Tanggal Ambil adalah besok
            const threeDaysLater = new Date(today);
            threeDaysLater.setDate(threeDaysLater.getDate() + 2); // Tanggal Kembali 3 hari setelah ambil

            tglAmbilInput.valueAsDate = today;
            tglKembaliInput.valueAsDate = threeDaysLater;

            // Menampilkan modal
            document.getElementById("bookingModal").classList.remove("hidden");

            // Update total harga awal
            updateTotalHarga();
        }

        function closeBooking() {
            document.getElementById("nopol").value = "";
            harga = 0;
            // Menyembunyikan modal
            document.getElementById("bookingModal").classList.add("hidden");
        }

        function updateTotalHarga() {
            const tanggalAmbil = new Date(document.getElementById("tgl_ambil").value);
            const tanggalKembali = new Date(document.getElementById("tgl_kembali").value);
            const daysDifference = Math.ceil((tanggalKembali - tanggalAmbil) / (1000 * 60 * 60 * 24));
            const pakaiSupir = document.querySelector('input[name="supir"]:checked').value === "1";

            let totalHarga = harga * daysDifference;

            // Tambahkan biaya supir jika dipilih
            if (pakaiSupir) {
                totalHarga += 100000 * daysDifference;
            }

            document.getElementById("totalHarga").textContent = `Rp ${totalHarga.toLocaleString()}`;
        }

        function validateForm() {
            const errorMessage = document.getElementById("errorMessage");
            const tanggalAmbil = new Date(document.getElementById("tgl_ambil").value);
            const tanggalKembali = new Date(document.getElementById("tgl_kembali").value);
            const dp = parseFloat(document.getElementById("dp").value);
            const hargaSewa = harga;

            // Clear previous error messages
            errorMessage.classList.add("hidden");
            errorMessage.textContent = "";

            // Validation for Tanggal Ambil (should be at least tomorrow)
            const minAmbilDate = new Date();
            minAmbilDate.setDate(minAmbilDate.getDate() + 1);
            if (tanggalAmbil < minAmbilDate) {
                errorMessage.textContent = "Tanggal Ambil minimal besok.";
                errorMessage.classList.remove("hidden");
                return false;
            }

            // Validation for Tanggal Kembali (should be at least 1 day after Tanggal Ambil)
            const minReturnDate = new Date(tanggalAmbil);
            minReturnDate.setDate(minReturnDate.getDate() + 1);
            if (tanggalKembali < minReturnDate) {
                errorMessage.textContent = "Tanggal Kembali minimal sehari setelah Tanggal Ambil.";
                errorMessage.classList.remove("hidden");
                return false;
            }

            // Validation for DP (should be between 20% and 100% of hargaSewa)
            const minDp = hargaSewa * 0.2;
            const maxDp = hargaSewa;
            if (dp < minDp || dp > maxDp) {
                errorMessage.textContent = `DP harus antara Rp ${minDp.toLocaleString()} dan Rp ${maxDp.toLocaleString()}.`;
                errorMessage.classList.remove("hidden");
                return false;
            }

            // If all validations pass, allow the form to submit
            return true;
        }

        // Event listeners untuk update total harga dan validasi saat input berubah
        document.getElementById("tgl_ambil").addEventListener("change", () => {
            validateForm();
            updateTotalHarga();
        });

        document.getElementById("tgl_kembali").addEventListener("change", () => {
            validateForm();
            updateTotalHarga();
        });

        document.querySelectorAll('input[name="supir"]').forEach(radio => {
            radio.addEventListener("change", updateTotalHarga);
        });
    </script>


</body>

</html>